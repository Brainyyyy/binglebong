export type ShaderType = 'Render' | 'Solid' | 'Wireframe';

export interface ProjectStats {
  objects?: string;
  vertices?: string;
  faces?: string;
  renderTime?: string;
  engine?: string;
  [key: string]: string | undefined;
}

export type ProjectCategory = 'Characters' | 'Environments' | 'Architecture' | 'Objects' | string;

export interface ProjectItem {
  id: string;
  title: string;
  subtitle?: string;
  koreanSub?: string;
  category: ProjectCategory;
  date: string; // e.g., "OCT 2024" or "2024"
  indexNumber: string; // e.g. "01"
  dimension?: string; // e.g. "3840 × 2160"
  aspectRatio?: string; // e.g. "16:9" or dimension
  // Shaders views
  imageUrl: string; // Render view (primary)
  solidUrl?: string; // Solid view (optional)
  wireframeUrl?: string; // Wireframe view (optional)
  description: string;
  notes?: string; // Custom notes
  stats: ProjectStats;
  featured?: boolean;
}

export type ViewMode = 'editorial' | 'grid';

