import { ProjectItem } from '../types';

import cyberRoninImg from '../assets/images/cyber_ronin_char_1789148127570.jpg';
import roninSolidImg from '../assets/images/ronin_solid_clay_1789148220165.jpg';
import roninWireframeImg from '../assets/images/ronin_wireframe_1789148237803.jpg';

import natureLandscapeImg from '../assets/images/nature_landscape_3d_1789148146925.jpg';
import cyberChassisImg from '../assets/images/cyber_chassis_1789144177904.jpg';
import kinseiPavilionImg from '../assets/images/kinsei_pavilion_1789144148812.jpg';
import zenDetailImg from '../assets/images/zen_detail_1789144206656.jpg';

export const INITIAL_PROJECTS: ProjectItem[] = [
  {
    id: 'cyber-ronin',
    title: 'CYBER RONIN WARRIOR',
    subtitle: 'Character Modeling (01)',
    category: 'Characters',
    date: 'NOV 2024',
    indexNumber: '01 / 05',
    dimension: '3840 × 2160',
    aspectRatio: '3840 × 2160',
    imageUrl: cyberRoninImg,
    solidUrl: roninSolidImg,
    wireframeUrl: roninWireframeImg,
    description: 'High-fidelity cybernetic ronin character sculpt in Blender. Features procedural micro-surface texturing, layered composite armor plating, and physical cloth simulation.',
    notes: 'Includes complete production topology quad mesh, solid clay pass, and path-traced skin shader.',
    stats: {
      objects: '142 Meshes',
      vertices: '3,840,210',
      faces: '3,790,500',
      renderTime: '18m 42s',
      engine: 'Blender Cycles',
    },
    featured: true,
  },
  {
    id: 'alpine-basalt-fjord',
    title: 'ALPINE BASALT & FJORD MIST',
    subtitle: 'Atmospheric Environment (02)',
    category: 'Environments',
    date: 'OCT 2024',
    indexNumber: '02 / 05',
    dimension: '3840 × 2160',
    aspectRatio: '3840 × 2160',
    imageUrl: natureLandscapeImg,
    description: 'Procedural mountain fjord environment created in Blender focusing on volumetric morning fog, mossy basalt cliff formations, and multi-layered foliage geometry nodes scattering.',
    notes: 'Principled BSDF sub-surface scattering tuned for wet alpine moss with physical sun vector lighting.',
    stats: {
      objects: '89 Instanced Clusters',
      vertices: '8,420,100',
      faces: '8,150,000',
      renderTime: '34m 10s',
      engine: 'Blender Cycles',
    },
    featured: true,
  },
  {
    id: 'neural-chassis',
    title: 'NEURAL CHASSIS TYPE-07',
    subtitle: 'Mechanical Asset (03)',
    category: 'Objects',
    date: 'AUG 2024',
    indexNumber: '03 / 05',
    dimension: '2880 × 2160',
    aspectRatio: '2880 × 2160',
    imageUrl: cyberChassisImg,
    description: 'Precision mechanical packaging concept. Modeled and textured in Blender with laser-etched fiducials, calculated bevels, and micro-scratched roughness maps.',
    notes: 'Clean quad mesh with weighted normal smoothing and procedural anodized metal shaders.',
    stats: {
      objects: '318 Meshes',
      vertices: '2,950,400',
      faces: '2,880,100',
      renderTime: '12m 15s',
      engine: 'Blender Cycles',
    },
    featured: true,
  },
  {
    id: 'kinsei-pavilion',
    title: 'KINSEI PAVILION',
    subtitle: 'Architectural Form & Light (04)',
    category: 'Architecture',
    date: 'MAY 2024',
    indexNumber: '04 / 05',
    dimension: '3840 × 2160',
    aspectRatio: '3840 × 2160',
    imageUrl: kinseiPavilionImg,
    description: 'Traditional timber joinery interacting with dark reflective water. Disciplined geometric framing, physical twilight illumination, and tactile charred shou sugi ban wood grain.',
    notes: 'Path-traced caustic simulation in reflecting basin with 4,096 Cycles samples.',
    stats: {
      objects: '76 Assemblies',
      vertices: '4,810,000',
      faces: '4,650,200',
      renderTime: '22m 04s',
      engine: 'Blender Cycles',
    },
    featured: false,
  },
  {
    id: 'tactile-monolith',
    title: 'TACTILE MONOLITH',
    subtitle: 'Material & Lighting (05)',
    category: 'Objects',
    date: 'JAN 2024',
    indexNumber: '05 / 05',
    dimension: '2160 × 2880',
    aspectRatio: '2160 × 2880',
    imageUrl: zenDetailImg,
    description: 'Close-up material and lighting exploration in Blender focusing on micro-surfacing, cedar grain roughness variation, and shadow graduation across precision bevels under raked early morning light.',
    notes: 'Procedural curvature shader and 32-bit floating point depth pass.',
    stats: {
      objects: '12 Meshes',
      vertices: '1,450,000',
      faces: '1,420,000',
      renderTime: '08m 30s',
      engine: 'Blender Cycles',
    },
    featured: false,
  },
];

export const STORAGE_KEY = 'chase_sutton_3d_portfolio_v4';

export function getStoredProjects(): ProjectItem[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error loading projects from localStorage', err);
  }
  return INITIAL_PROJECTS;
}

export function saveStoredProjects(projects: ProjectItem[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
  } catch (err) {
    console.error('Error saving projects to localStorage', err);
  }
}
