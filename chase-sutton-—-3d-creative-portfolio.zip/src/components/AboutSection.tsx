import React from 'react';
import { motion } from 'motion/react';
import { Logo } from './Logo';

export const AboutSection: React.FC = () => {
  return (
    <section
      id="about-section"
      className="pt-16 pb-20 border-b border-neutral-800 bg-[#070707] relative overflow-hidden"
    >
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="block">
          {/* Left Column: Branding & Artist Overview */}
          <div className="lg:float-left lg:w-1/2 lg:pr-12">
            <div className="flex items-center space-x-3 text-xs font-mono text-neutral-400 mb-4">
              <span className="text-white font-semibold tracking-widest uppercase font-mono">
                02 // ABOUT
              </span>
              <span className="text-neutral-600">/</span>
              <span className="text-neutral-300 tracking-widest uppercase font-mono">
                CHASE SUTTON
              </span>
              <span className="text-neutral-600">/</span>
              <span className="tracking-widest uppercase text-neutral-500">
                3D CREATIVE ARTIST
              </span>
            </div>

            <h2 className="font-['Cinzel'] text-4xl sm:text-6xl text-white tracking-tight leading-[0.95] uppercase font-bold">
              CHASE
              <br />
              SUTTON
            </h2>

            <div className="mt-8 border-l-2 border-white pl-6 py-2">
              <p className="font-sans text-neutral-300 text-base sm:text-lg leading-relaxed max-w-lg">
                Just my hobby where I torture myself for fun. I’m always trying to create something new, or put my own twist on what I create. I tend to avoid relying heavily on tutorials, opting to figure it out myself instead.
              </p>
            </div>

            <div className="mt-8 flex items-center space-x-6">
              <Logo size="xl" showText={false} />

              <div className="text-xs font-mono text-neutral-400 space-y-1">
                <span className="block text-white uppercase tracking-wider font-semibold">
                  Chase Sutton
                </span>
                <span className="block text-neutral-500">
                  36° 50' 54" S, 174° 45' 48" E
                </span>
                <span className="block text-neutral-500">
                  EST. 2020 — PRESENT
                </span>
              </div>
            </div>
          </div>

          {/* Right Column / Main About Text */}
          <div className="space-y-6 text-sm font-sans text-neutral-400 leading-relaxed pt-2">
            <p>
              I started my journey back in 2020 when a friend introduced me to this cool 3D software called Blender. This was at the peak of COVID, when I had plenty of free time on my hands, so I spent a good amount of time on it and quickly became overly hooked, as I tend to do with many new thing.
            </p>

            <p>
              During the first couple of years, I explored a lot of different ideas, which really helped me develop my skills quickly. Once I reached Year 11, I began DVC (high school architecture), which got me thinking more about function and helped me understand referencing a lot better.
            </p>

            <p>
              During those next few years I went through a bit of a dry spout when I only really made one or two proper projects but I never really completely dropped Blender.
            </p>

            <p>
              These days, i've picked up the pace a bit again with some of my new projects like Iljumun but I am a bit more stubborn about just creating whatever I want, and I often need something functional, like a background or maybe something for a game or stream, to motivate me. One outlet I’ve really grasped onto for new ideas is Korean culture, as it’s a pretty important part of my life. I’ve become so accustomed to Blender now that I even use it for many 2D projects.
            </p>

            <p>
              My skills have definitely improved over the years, which I think is pretty evident in the renders over time. However, there are still a few things I struggle with. One skill I’ve spent really no time on at all is topology and keeping a lower poly count where possible. Not that these things haven’t improved, but, to be honest, it’s very much “out of sight, out of mind” for me. They generally don’t have much of an impact on the final result, so I tend not to care too much.
            </p>

            <p>
              The other skill I have yet to develop is damn characters. I hate creating characters. And the final skill I’m still pretty terrible at is animation. I generally haven’t had much of a use for animation, so it’s something I’ve sort of pushed to the side and forgotten about. But yeah, character design and animation seriously scare me, so I’d rather just stick to my own lane, I think haha.
            </p>

            <p>
              Anyway, I’m always looking for new ideas, so if you have any you think I might like, definitely hit me up. I’m always interested in hearing something new.
            </p>

            <div className="pt-4 flex flex-wrap items-center gap-6 text-xs font-mono text-neutral-400">
              <span className="text-white">BLENDER 3D WORKFLOW</span>
              <span className="text-neutral-700">•</span>
              <span className="text-neutral-500">
                DIGITAL SCULPTING & SHADERS
              </span>
            </div>
          </div>

          {/* Prevent anything below this section from wrapping around the float */}
          <div className="clear-both" />
        </div>
      </div>
    </section>
  );
};