import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'md', showText = true }) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-10 h-10',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20',
  };

  return (
    <div className={`inline-flex items-center gap-3 whitespace-nowrap shrink-0 ${className}`}>
      {/* Signature Circular Logo (DesignLogoSmall.png) */}
      <div className={`relative shrink-0 rounded-full overflow-hidden border border-neutral-800 bg-black ${iconSizes[size]}`}>
        <img
          src="/DesignLogoSmall.png"
          alt="Chase Sutton Logo"
          className="w-full h-full object-cover block"
          loading="eager"
        />
      </div>

      {showText && (
        <div className="flex flex-col tracking-tight whitespace-nowrap shrink-0 text-left">
          <div className="flex items-center gap-2 whitespace-nowrap">
            <span className="font-['Cinzel'] font-bold tracking-[0.22em] text-white text-sm md:text-base uppercase whitespace-nowrap">
              CHASE SUTTON
            </span>
            <span className="text-[9px] font-mono tracking-widest text-neutral-400 border border-neutral-800 px-1.5 py-0.5 uppercase bg-neutral-900/60 whitespace-nowrap">
              3D
            </span>
          </div>
          <span className="text-[10px] font-mono tracking-[0.22em] text-neutral-400 uppercase whitespace-nowrap">
            3D CREATIVE ARCHIVE
          </span>
        </div>
      )}
    </div>
  );
};

