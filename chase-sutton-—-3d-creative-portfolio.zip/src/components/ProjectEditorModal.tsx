import React, { useState, useEffect, useRef } from 'react';
import { ProjectItem, ProjectCategory, ProjectStats } from '../types';
import { X, Upload, Plus, Trash2, Image as ImageIcon, AlertCircle, Layers, Check, Star } from 'lucide-react';

interface ProjectEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveProject: (project: ProjectItem) => void;
  editingProject?: ProjectItem | null;
  totalProjects: number;
}

export const ProjectEditorModal: React.FC<ProjectEditorModalProps> = ({
  isOpen,
  onClose,
  onSaveProject,
  editingProject,
  totalProjects,
}) => {
  const isEdit = !!editingProject;

  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [category, setCategory] = useState<ProjectCategory>('Characters');
  const [date, setDate] = useState('');
  const [aspectRatio, setAspectRatio] = useState<string>('16:9');
  const [description, setDescription] = useState('');
  const [notes, setNotes] = useState('');
  const [isFeatured, setIsFeatured] = useState<boolean>(false);

  // Shader View Images
  const [renderImg, setRenderImg] = useState<string>('');
  const [solidImg, setSolidImg] = useState<string>('');
  const [wireframeImg, setWireframeImg] = useState<string>('');

  // Primary Stats
  const [engine, setEngine] = useState('');
  const [objects, setObjects] = useState('');
  const [vertices, setVertices] = useState('');
  const [faces, setFaces] = useState('');
  const [renderTime, setRenderTime] = useState('');

  // Custom Extra Stats (Key - Value)
  const [customStats, setCustomStats] = useState<Array<{ id: string; key: string; value: string }>>([]);

  const [error, setError] = useState<string>('');

  // Populate state when opening or switching editingProject
  useEffect(() => {
    if (editingProject) {
      setTitle(editingProject.title);
      setSubtitle(editingProject.subtitle || editingProject.koreanSub || '');
      setCategory(editingProject.category);
      setDate(editingProject.date || '');
      setAspectRatio(editingProject.aspectRatio || '16:9');
      setDescription(editingProject.description || '');
      setNotes(editingProject.notes || '');
      setIsFeatured(editingProject.featured ?? false);

      setRenderImg(editingProject.imageUrl || '');
      setSolidImg(editingProject.solidUrl || '');
      setWireframeImg(editingProject.wireframeUrl || '');

      const stats = editingProject.stats || {};
      setEngine(stats.engine || 'Blender Cycles');
      setObjects(stats.objects || '');
      setVertices(stats.vertices || '');
      setFaces(stats.faces || '');
      setRenderTime(stats.renderTime || '');

      // Load extra custom stats
      const extra = Object.entries(stats)
        .filter(([k]) => !['engine', 'objects', 'vertices', 'faces', 'renderTime'].includes(k))
        .map(([k, v]) => ({ id: Math.random().toString(), key: k, value: v || '' }));
      setCustomStats(extra);
    } else {
      // Default blank values for new project
      setTitle('');
      setSubtitle(`3D Archive (${String(totalProjects + 1).padStart(2, '0')})`);
      setCategory('Characters');
      const now = new Date();
      const monthNames = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
      setDate(`${monthNames[now.getMonth()]} ${now.getFullYear()}`);
      setAspectRatio('16:9');
      setDescription('');
      setNotes('');
      setIsFeatured(false);
      setRenderImg('');
      setSolidImg('');
      setWireframeImg('');
      setEngine('Blender Cycles');
      setObjects('');
      setVertices('');
      setFaces('');
      setRenderTime('');
      setCustomStats([]);
    }
    setError('');
  }, [editingProject, isOpen, totalProjects]);

  if (!isOpen) return null;

  // File upload reader helper
  const handleUploadImage = (file: File, target: 'render' | 'solid' | 'wireframe') => {
    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file (JPG, PNG, WEBP).');
      return;
    }
    setError('');
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        const url = e.target.result as string;
        if (target === 'render') setRenderImg(url);
        if (target === 'solid') setSolidImg(url);
        if (target === 'wireframe') setWireframeImg(url);
      }
    };
    reader.readAsDataURL(file);
  };

  const addCustomStat = () => {
    setCustomStats((prev) => [...prev, { id: Math.random().toString(), key: '', value: '' }]);
  };

  const removeCustomStat = (id: string) => {
    setCustomStats((prev) => prev.filter((item) => item.id !== id));
  };

  const updateCustomStat = (id: string, field: 'key' | 'value', text: string) => {
    setCustomStats((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: text } : item))
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Project title is required.');
      return;
    }
    if (!renderImg) {
      setError('A Render view image is required.');
      return;
    }

    // Build flexible stats object
    const finalStats: ProjectStats = {};
    if (engine.trim()) finalStats.engine = engine.trim();
    if (objects.trim()) finalStats.objects = objects.trim();
    if (vertices.trim()) finalStats.vertices = vertices.trim();
    if (faces.trim()) finalStats.faces = faces.trim();
    if (renderTime.trim()) finalStats.renderTime = renderTime.trim();

    customStats.forEach((st) => {
      if (st.key.trim() && st.value.trim()) {
        finalStats[st.key.trim()] = st.value.trim();
      }
    });

    const projectData: ProjectItem = {
      id: editingProject ? editingProject.id : `project-${Date.now()}`,
      title: title.trim().toUpperCase(),
      subtitle: subtitle.trim() || undefined,
      koreanSub: subtitle.trim() || undefined,
      category,
      date: date.trim() || '2024',
      indexNumber: editingProject ? editingProject.indexNumber : `${String(totalProjects + 1).padStart(2, '0')} / ${String(totalProjects + 1).padStart(2, '0')}`,
      aspectRatio: aspectRatio.trim() || '16:9',
      imageUrl: renderImg,
      solidUrl: solidImg.trim() || undefined,
      wireframeUrl: wireframeImg.trim() || undefined,
      description: description.trim() || 'Creative 3D computational model and shader study.',
      notes: notes.trim() || undefined,
      stats: finalStats,
      featured: isFeatured,
    };

    onSaveProject(projectData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-3 sm:p-6 overflow-y-auto">
      <div className="w-full max-w-4xl bg-[#0c0c0c] border border-neutral-700 max-h-[92vh] flex flex-col overflow-hidden text-neutral-200 shadow-2xl">
        {/* Header */}
        <div className="h-14 border-b border-neutral-800 bg-[#080808] px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            <span className="font-mono text-xs font-bold text-white tracking-widest uppercase">
              {isEdit ? 'EDIT 3D PROJECT' : 'ADD NEW 3D PROJECT'}
            </span>
            <span className="text-neutral-600">/</span>
            <span className="text-xs font-mono text-neutral-400">CHASE SUTTON ARCHIVE</span>
          </div>

          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Error message */}
        {error && (
          <div className="bg-red-950/80 border-b border-red-800 px-6 py-2.5 text-xs font-mono text-red-200 flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-8">
          {/* Section 1: Basic Information */}
          <div className="space-y-4">
            <div className="border-b border-neutral-800 pb-2 flex items-center justify-between">
              <span className="font-mono text-xs text-white uppercase tracking-wider font-semibold">
                01 // PROJECT OVERVIEW
              </span>
              <span className="text-[10px] font-mono text-neutral-500">REQUIRED & CORE FIELDS</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-[11px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                  Project Title *
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. CYBER RONIN WARRIOR"
                  className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-3 py-2 text-xs font-mono text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                  Category *
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ProjectCategory)}
                  className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-3 py-2 text-xs font-mono text-white outline-none"
                >
                  <option value="Characters">Characters</option>
                  <option value="Environments">Environments</option>
                  <option value="Architecture">Architecture</option>
                  <option value="Objects">Objects</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                  Date / Timeline
                </label>
                <input
                  type="text"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  placeholder="e.g. NOV 2024 or 2024"
                  className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-3 py-2 text-xs font-mono text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                  Aspect Ratio
                </label>
                <input
                  type="text"
                  value={aspectRatio}
                  onChange={(e) => setAspectRatio(e.target.value)}
                  placeholder="e.g. 16:9, 4:3, 21:9"
                  className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-3 py-2 text-xs font-mono text-white outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[11px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                  Project Subtitle (Optional)
                </label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  placeholder="e.g. Character Modeling (01)"
                  className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-3 py-2 text-xs font-mono text-white outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                Description / Rationale
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="High-fidelity 3D sculpt focusing on procedural surfaces, volumetric lighting, and physical shaders..."
                className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-3 py-2 text-xs font-sans text-neutral-300 outline-none leading-relaxed"
              />
            </div>

            {/* Featured Checkbox */}
            <label className={`flex items-center space-x-3 cursor-pointer select-none p-3 border transition-colors ${
              isFeatured ? 'border-white bg-[#181818]' : 'border-neutral-800 bg-[#121212] hover:border-neutral-600'
            }`}>
              <input
                type="checkbox"
                checked={isFeatured}
                onChange={(e) => setIsFeatured(e.target.checked)}
                className="w-4 h-4 accent-white bg-neutral-900 border-neutral-700 cursor-pointer"
              />
              <div className="flex flex-col">
                <span className="font-mono text-xs text-white uppercase tracking-wider font-semibold flex items-center space-x-1.5">
                  <Star className={`w-3.5 h-3.5 ${isFeatured ? 'text-white fill-white' : 'text-neutral-500'}`} />
                  <span>Feature this project in Hero showcase</span>
                </span>
                <span className="text-[10px] font-mono text-neutral-400">
                  When checked, this project takes the spotlight in the opening hero cinematic presentation.
                </span>
              </div>
            </label>
          </div>

          {/* Section 2: Multi-Shader Views (Wireframe, Solid, Render) */}
          <div className="space-y-4">
            <div className="border-b border-neutral-800 pb-2 flex items-center justify-between">
              <div>
                <span className="font-mono text-xs text-white uppercase tracking-wider font-semibold">
                  02 // SHADER VIEWS (WIREFRAME / SOLID / RENDER)
                </span>
                <p className="text-[10px] font-mono text-neutral-500 mt-0.5">
                  Upload the views you have. On the website, users can only select views that you upload.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* 1. Render View (Primary) */}
              <div className="border border-neutral-800 bg-[#111111] p-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs font-bold text-white uppercase">[RENDER] VIEW *</span>
                    <span className="text-[9px] font-mono text-emerald-400">Primary Full Color</span>
                  </div>
                  <div className="aspect-[16/10] bg-black border border-neutral-800 relative overflow-hidden mb-3 flex items-center justify-center">
                    {renderImg ? (
                      <img src={renderImg} alt="Render Preview" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-[10px] font-mono text-neutral-600 text-center px-2">
                        No Render Image
                      </span>
                    )}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block w-full border border-neutral-700 hover:border-white bg-neutral-900 hover:bg-neutral-800 text-center py-1.5 text-[11px] font-mono text-white cursor-pointer transition-colors">
                    Upload Render
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => e.target.files?.[0] && handleUploadImage(e.target.files[0], 'render')}
                    />
                  </label>
                  <input
                    type="text"
                    value={renderImg}
                    onChange={(e) => setRenderImg(e.target.value)}
                    placeholder="Or paste image URL"
                    className="w-full bg-[#181818] border border-neutral-800 px-2 py-1 text-[10px] font-mono text-neutral-400 outline-none"
                  />
                </div>
              </div>

              {/* 2. Solid View (Optional) */}
              <div className="border border-neutral-800 bg-[#111111] p-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs font-bold text-neutral-300 uppercase">[SOLID] VIEW</span>
                    <span className="text-[9px] font-mono text-neutral-500">Optional</span>
                  </div>
                  <div className="aspect-[16/10] bg-black border border-neutral-800 relative overflow-hidden mb-3 flex items-center justify-center">
                    {solidImg ? (
                      <img src={solidImg} alt="Solid Preview" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-[10px] font-mono text-neutral-600 text-center px-2">
                        Not uploaded (Option will be hidden)
                      </span>
                    )}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center space-x-1">
                    <label className="flex-1 border border-neutral-700 hover:border-white bg-neutral-900 hover:bg-neutral-800 text-center py-1.5 text-[11px] font-mono text-white cursor-pointer transition-colors">
                      Upload Solid
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => e.target.files?.[0] && handleUploadImage(e.target.files[0], 'solid')}
                      />
                    </label>
                    {solidImg && (
                      <button
                        type="button"
                        onClick={() => setSolidImg('')}
                        title="Remove Solid View"
                        className="border border-neutral-800 p-1.5 text-neutral-500 hover:text-red-400"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <input
                    type="text"
                    value={solidImg}
                    onChange={(e) => setSolidImg(e.target.value)}
                    placeholder="Or paste image URL"
                    className="w-full bg-[#181818] border border-neutral-800 px-2 py-1 text-[10px] font-mono text-neutral-400 outline-none"
                  />
                </div>
              </div>

              {/* 3. Wireframe View (Optional) */}
              <div className="border border-neutral-800 bg-[#111111] p-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs font-bold text-neutral-300 uppercase">[WIREFRAME] VIEW</span>
                    <span className="text-[9px] font-mono text-neutral-500">Optional</span>
                  </div>
                  <div className="aspect-[16/10] bg-black border border-neutral-800 relative overflow-hidden mb-3 flex items-center justify-center">
                    {wireframeImg ? (
                      <img src={wireframeImg} alt="Wireframe Preview" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-[10px] font-mono text-neutral-600 text-center px-2">
                        Not uploaded (Option will be hidden)
                      </span>
                    )}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center space-x-1">
                    <label className="flex-1 border border-neutral-700 hover:border-white bg-neutral-900 hover:bg-neutral-800 text-center py-1.5 text-[11px] font-mono text-white cursor-pointer transition-colors">
                      Upload Wireframe
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => e.target.files?.[0] && handleUploadImage(e.target.files[0], 'wireframe')}
                      />
                    </label>
                    {wireframeImg && (
                      <button
                        type="button"
                        onClick={() => setWireframeImg('')}
                        title="Remove Wireframe View"
                        className="border border-neutral-800 p-1.5 text-neutral-500 hover:text-red-400"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <input
                    type="text"
                    value={wireframeImg}
                    onChange={(e) => setWireframeImg(e.target.value)}
                    placeholder="Or paste image URL"
                    className="w-full bg-[#181818] border border-neutral-800 px-2 py-1 text-[10px] font-mono text-neutral-400 outline-none"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Flexible Stats (Objects, Vertices, Faces, Render Time, Engine, + Custom) */}
          <div className="space-y-4">
            <div className="border-b border-neutral-800 pb-2 flex items-center justify-between">
              <div>
                <span className="font-mono text-xs text-white uppercase tracking-wider font-semibold">
                  03 // FLEXIBLE 3D STATS
                </span>
                <p className="text-[10px] font-mono text-neutral-500 mt-0.5">
                  Fill in the stats you want to display; blank stats will not appear on the project card.
                </p>
              </div>

              <button
                type="button"
                onClick={addCustomStat}
                className="border border-neutral-700 hover:border-white bg-neutral-900 hover:bg-neutral-800 px-2.5 py-1 text-[10px] font-mono text-neutral-300 hover:text-white flex items-center space-x-1 transition-colors"
              >
                <Plus className="w-3 h-3" />
                <span>Add Custom Stat</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1">
                  Engine
                </label>
                <input
                  type="text"
                  value={engine}
                  onChange={(e) => setEngine(e.target.value)}
                  placeholder="e.g. Blender Cycles"
                  className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-2.5 py-1.5 text-xs font-mono text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1">
                  Objects
                </label>
                <input
                  type="text"
                  value={objects}
                  onChange={(e) => setObjects(e.target.value)}
                  placeholder="e.g. 142 Meshes"
                  className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-2.5 py-1.5 text-xs font-mono text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1">
                  Vertices
                </label>
                <input
                  type="text"
                  value={vertices}
                  onChange={(e) => setVertices(e.target.value)}
                  placeholder="e.g. 3,840,210"
                  className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-2.5 py-1.5 text-xs font-mono text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1">
                  Faces
                </label>
                <input
                  type="text"
                  value={faces}
                  onChange={(e) => setFaces(e.target.value)}
                  placeholder="e.g. 3,790,500"
                  className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-2.5 py-1.5 text-xs font-mono text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1">
                  Render Time
                </label>
                <input
                  type="text"
                  value={renderTime}
                  onChange={(e) => setRenderTime(e.target.value)}
                  placeholder="e.g. 18m 42s"
                  className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-2.5 py-1.5 text-xs font-mono text-white outline-none"
                />
              </div>
            </div>

            {/* Custom Stat Rows */}
            {customStats.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-neutral-800/80">
                <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-wider block">
                  Custom Additional Specs:
                </span>
                {customStats.map((item) => (
                  <div key={item.id} className="flex items-center space-x-2">
                    <input
                      type="text"
                      placeholder="Stat Label (e.g. Software)"
                      value={item.key}
                      onChange={(e) => updateCustomStat(item.id, 'key', e.target.value)}
                      className="w-1/3 bg-[#141414] border border-neutral-800 px-2.5 py-1 text-xs font-mono text-white outline-none"
                    />
                    <input
                      type="text"
                      placeholder="Value (e.g. ZBrush + Marvelous)"
                      value={item.value}
                      onChange={(e) => updateCustomStat(item.id, 'value', e.target.value)}
                      className="flex-1 bg-[#141414] border border-neutral-800 px-2.5 py-1 text-xs font-mono text-white outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => removeCustomStat(item.id)}
                      className="border border-neutral-800 p-1.5 text-neutral-500 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Additional Notes */}
            <div>
              <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1">
                Additional Technical Notes (Optional)
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Multi-resolution displacement pass, sub-surface scattering, ACEScg color pipeline"
                className="w-full bg-[#141414] border border-neutral-800 focus:border-white px-3 py-1.5 text-xs font-mono text-neutral-300 outline-none"
              />
            </div>
          </div>

          {/* Footer Submit */}
          <div className="border-t border-neutral-800 pt-4 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="border border-neutral-800 hover:border-neutral-600 px-5 py-2.5 text-xs font-mono uppercase tracking-wider text-neutral-400 hover:text-white transition-colors"
            >
              Cancel
            </button>

            <button
              type="submit"
              className="border border-white bg-white text-black hover:bg-neutral-200 px-6 py-2.5 text-xs font-mono uppercase tracking-widest font-bold transition-colors flex items-center space-x-2"
            >
              <Check className="w-4 h-4" />
              <span>{isEdit ? 'Save Project Changes' : 'Add Project to Archive'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
