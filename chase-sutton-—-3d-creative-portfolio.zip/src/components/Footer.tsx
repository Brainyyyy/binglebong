import React from 'react';
import { ArrowUp } from 'lucide-react';
import { Logo } from './Logo';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-neutral-800 bg-[#050505] text-neutral-400 py-12 text-xs font-mono">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-b border-neutral-800/80 pb-8">
          <div className="flex items-center space-x-4">
            <Logo size="sm" showText={true} />
            <span className="text-neutral-600 hidden sm:inline">|</span>
            <span className="text-[11px] text-neutral-500 uppercase tracking-widest hidden sm:inline">
              3D CREATIVE PORTFOLIO
            </span>
          </div>

          <div className="flex items-center space-x-6">
            <span className="text-neutral-500">EST. 2020 — PRESENT</span>
            <span className="text-neutral-700">|</span>
            <button
              onClick={scrollToTop}
              className="border border-neutral-800 hover:border-white bg-[#0e0e0e] text-neutral-300 hover:text-white px-3 py-1.5 flex items-center space-x-1.5 transition-colors uppercase tracking-wider text-[11px]"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-neutral-600 text-[11px] gap-4">
          <div>
            © {new Date().getFullYear()} CHASE SUTTON // ALL RIGHTS RESERVED. 3D CREATIVE ARCHIVE.
          </div>
          <div className="flex items-center space-x-4">
            <span className="font-mono text-neutral-500">36° 50' 54" S, 174° 45' 48" E</span>
            <span className="text-neutral-700">/</span>
            <span className="text-neutral-400">STUDIO ARCHIVE</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
