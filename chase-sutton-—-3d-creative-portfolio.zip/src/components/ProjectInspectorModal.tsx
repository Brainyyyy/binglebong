import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ProjectItem, ShaderType } from '../types';
import { 
  X, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Download, 
  ChevronLeft, 
  ChevronRight, 
  Check,
  Edit3,
  Trash2,
  Share2,
  Star
} from 'lucide-react';

interface ProjectInspectorModalProps {
  project: ProjectItem | null;
  onClose: () => void;
  onNavigate: (direction: 'next' | 'prev') => void;
  onEditProject?: (project: ProjectItem) => void;
  onDeleteProject?: (id: string) => void;
  onSetFeatured?: (id: string) => void;
}

export const ProjectInspectorModal: React.FC<ProjectInspectorModalProps> = ({
  project,
  onClose,
  onNavigate,
  onEditProject,
  onDeleteProject,
  onSetFeatured,
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [activeShader, setActiveShader] = useState<ShaderType>('Render');
  const [copied, setCopied] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  // Available shaders based on uploaded views
  const availableShaders: ShaderType[] = project
    ? (['Render', project.solidUrl && 'Solid', project.wireframeUrl && 'Wireframe'].filter(Boolean) as ShaderType[])
    : ['Render'];

  // Reset zoom & shader when project changes
  useEffect(() => {
    setZoomLevel(1);
    setActiveShader('Render');
  }, [project]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!project) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') onNavigate('next');
      if (e.key === 'ArrowLeft') onNavigate('prev');
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [project, onClose, onNavigate]);

  if (!project) return null;

  const handleZoomIn = () => setZoomLevel((prev) => Math.min(prev + 0.3, 2.5));
  const handleZoomOut = () => setZoomLevel((prev) => Math.max(prev - 0.3, 0.8));
  const handleResetZoom = () => setZoomLevel(1);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Determine which image to show based on shader
  const currentImage = (activeShader === 'Solid' && project.solidUrl)
    ? project.solidUrl
    : (activeShader === 'Wireframe' && project.wireframeUrl)
    ? project.wireframeUrl
    : project.imageUrl;

  // Watermarked Image Download: draws current view + square logo in bottom right
  const handleDownloadWithWatermark = async () => {
    if (isDownloading) return;
    try {
      setIsDownloading(true);

      const mainImg = new Image();
      mainImg.crossOrigin = 'anonymous';

      await new Promise<void>((resolve, reject) => {
        mainImg.onload = () => resolve();
        mainImg.onerror = () => reject(new Error('Failed to load main project image'));
        mainImg.src = currentImage;
      });

      const canvas = document.createElement('canvas');
      const naturalWidth = mainImg.naturalWidth || 1920;
      const naturalHeight = mainImg.naturalHeight || 1080;
      canvas.width = naturalWidth;
      canvas.height = naturalHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Could not get 2D canvas context');

      // Draw the main image full resolution
      ctx.drawImage(mainImg, 0, 0, naturalWidth, naturalHeight);

      // Load Chase Sutton's signature logo
      const logoImg = new Image();
      logoImg.crossOrigin = 'anonymous';

      await new Promise<void>((resolve, reject) => {
        logoImg.onload = () => resolve();
        logoImg.onerror = () => reject(new Error('Failed to load logo watermark'));
        logoImg.src = '/DesignLogoSmall.png';
      });

      // Calculate watermark size (enlarged: approx 12% of width, min 130px) and margins
      const baseLogoWidth = Math.max(130, Math.round(naturalWidth * 0.12));
      const logoAspect = (logoImg.naturalWidth || 1) / (logoImg.naturalHeight || 1);
      const logoWidth = baseLogoWidth;
      const logoHeight = Math.round(baseLogoWidth / logoAspect);

      // Shifted down and right further (bottom margin tighter than right margin)
      const marginRight = Math.max(10, Math.round(baseLogoWidth * 0.08));
      const marginBottom = Math.max(5, Math.round(baseLogoWidth * 0.03));
      const x = naturalWidth - logoWidth - marginRight;
      const y = naturalHeight - logoHeight - marginBottom;

      // Watermark in bottom-right corner: uncropped, no background, 50% opacity
      ctx.save();
      ctx.globalAlpha = 0.50;
      ctx.drawImage(logoImg, x, y, logoWidth, logoHeight);
      ctx.restore();

      // Trigger download
      canvas.toBlob((blob) => {
        if (!blob) {
          setIsDownloading(false);
          return;
        }
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        const sanitizedTitle = project.title.toLowerCase().replace(/[^a-z0-9]+/g, '_');
        link.download = `chase_sutton_${sanitizedTitle}_${activeShader.toLowerCase()}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        setIsDownloading(false);
      }, 'image/png', 0.98);
    } catch (err) {
      console.warn('Canvas watermarking error, falling back to direct download:', err);
      const link = document.createElement('a');
      link.href = currentImage;
      const sanitizedTitle = project.title.toLowerCase().replace(/[^a-z0-9]+/g, '_');
      link.download = `chase_sutton_${sanitizedTitle}_${activeShader.toLowerCase()}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setIsDownloading(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md p-2 sm:p-4 lg:p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.2 }}
          className="w-full h-full max-w-7xl max-h-[96vh] bg-[#0c0c0c] border border-neutral-700 flex flex-col overflow-hidden text-neutral-200 shadow-2xl"
        >
          {/* Top Inspector Header */}
          <div className="h-14 border-b border-neutral-800 bg-[#080808] px-4 sm:px-6 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <span className="font-mono text-xs font-bold text-white tracking-widest">
                INSPECTOR [{project.indexNumber}]
              </span>
              <span className="text-neutral-600">/</span>
              <span className="font-['Cinzel'] text-sm uppercase text-neutral-200 font-semibold truncate max-w-[200px] sm:max-w-md">
                {project.title}
              </span>
            </div>

            <div className="flex items-center space-x-2">
              {/* Make Featured Button */}
              {onSetFeatured && (
                <button
                  onClick={() => onSetFeatured(project.id)}
                  title={project.featured ? "Currently featured in hero" : "Make this the featured project"}
                  className={`px-2.5 py-1.5 border text-xs font-mono flex items-center space-x-1.5 transition-colors ${
                    project.featured
                      ? 'bg-white text-black border-white font-bold'
                      : 'border-neutral-800 hover:border-white bg-[#121212] text-neutral-300 hover:text-white'
                  }`}
                >
                  <Star className={`w-3.5 h-3.5 ${project.featured ? 'fill-black text-black' : ''}`} />
                  <span className="hidden sm:inline">{project.featured ? 'Featured' : 'Make Featured'}</span>
                </button>
              )}

              {/* Edit Button */}
              {onEditProject && (
                <button
                  onClick={() => onEditProject(project)}
                  title="Edit Project"
                  className="px-2.5 py-1.5 border border-neutral-800 hover:border-white bg-[#121212] text-neutral-300 hover:text-white transition-colors text-xs font-mono flex items-center space-x-1.5"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Edit</span>
                </button>
              )}

              {/* Delete Button */}
              {onDeleteProject && (
                <button
                  onClick={() => {
                    if (window.confirm(`Delete "${project.title}" from the portfolio?`)) {
                      onDeleteProject(project.id);
                      onClose();
                    }
                  }}
                  title="Delete Project"
                  className="px-2.5 py-1.5 border border-neutral-800 hover:border-red-500 bg-[#121212] text-neutral-400 hover:text-red-400 transition-colors text-xs font-mono flex items-center space-x-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Delete</span>
                </button>
              )}

              <div className="w-[1px] h-6 bg-neutral-800 mx-1" />

              {/* Prev / Next */}
              <button
                onClick={() => onNavigate('prev')}
                title="Previous Project (Left Arrow)"
                className="p-2 border border-neutral-800 hover:border-neutral-600 bg-[#121212] text-neutral-400 hover:text-white transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => onNavigate('next')}
                title="Next Project (Right Arrow)"
                className="p-2 border border-neutral-800 hover:border-neutral-600 bg-[#121212] text-neutral-400 hover:text-white transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>

              <div className="w-[1px] h-6 bg-neutral-800 mx-1" />

              {/* Close Button */}
              <button
                onClick={onClose}
                title="Close Inspector (Esc)"
                className="p-2 border border-neutral-800 hover:border-white bg-[#121212] text-neutral-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Center Main Stage */}
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
            {/* Viewport Canvas Area */}
            <div className="lg:col-span-8 bg-black relative flex flex-col justify-between overflow-hidden border-b lg:border-b-0 lg:border-r border-neutral-800">
              {/* Top Viewport Floating Controls */}
              <div className="absolute top-4 left-4 z-20 flex items-center space-x-2">
                {/* Shader mode switcher - only shows uploaded views! */}
                <div className="flex items-center border border-neutral-700 bg-black/85 backdrop-blur-sm p-1">
                  <span className="px-2 text-[10px] font-mono text-neutral-500 uppercase tracking-widest hidden sm:inline">
                    SHADER:
                  </span>
                  {availableShaders.length === 1 ? (
                    <span className="px-3 py-1 font-mono text-xs uppercase bg-neutral-800 text-white font-bold">
                      {availableShaders[0]}
                    </span>
                  ) : (
                    availableShaders.map((shader) => (
                      <button
                        key={shader}
                        onClick={() => setActiveShader(shader)}
                        className={`px-3 py-1 font-mono text-xs uppercase tracking-wider transition-colors ${
                          activeShader === shader
                            ? 'bg-white text-black font-bold'
                            : 'text-neutral-400 hover:text-white'
                        }`}
                      >
                        {shader}
                      </button>
                    ))
                  )}
                </div>
              </div>

              {/* Zoom Controls */}
              <div className="absolute top-4 right-4 z-20 flex items-center space-x-1 border border-neutral-700 bg-black/85 backdrop-blur-sm p-1">
                <button
                  onClick={handleZoomIn}
                  title="Zoom In"
                  className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                <button
                  onClick={handleZoomOut}
                  title="Zoom Out"
                  className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <button
                  onClick={handleResetZoom}
                  title="Reset Zoom"
                  className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
                <span className="text-[10px] text-neutral-400 px-2 font-mono">
                  {Math.round(zoomLevel * 100)}%
                </span>
              </div>

              {/* Image Stage Container - FULL COLOR (No grayscale filter!) */}
              <div className="flex-1 flex items-center justify-center p-4 sm:p-8 overflow-auto select-none">
                <div 
                  className="relative transition-transform duration-300 ease-out max-h-full max-w-full flex items-center justify-center"
                  style={{ transform: `scale(${zoomLevel})` }}
                >
                  <AnimatePresence mode="wait">
                    <motion.img
                      key={currentImage}
                      src={currentImage}
                      alt={`${project.title} - ${activeShader}`}
                      referrerPolicy="no-referrer"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.22, ease: 'easeInOut' }}
                      className="max-h-[65vh] w-auto object-contain border border-neutral-800 shadow-2xl"
                    />
                  </AnimatePresence>
                </div>
              </div>

              {/* Bottom Stage Status */}
              <div className="border-t border-neutral-800 bg-[#090909] px-4 py-2.5 flex items-center justify-between text-xs font-mono text-neutral-500">
                <div className="flex items-center space-x-3">
                  <span className="text-white font-mono">{project.date}</span>
                  <span>|</span>
                  <span>ASPECT: {project.aspectRatio}</span>
                  <span>|</span>
                  <span className="text-neutral-400">VIEW: {activeShader.toUpperCase()}</span>
                </div>

                <div className="flex items-center space-x-3">
                  <button
                    onClick={handleDownloadWithWatermark}
                    disabled={isDownloading}
                    className="flex items-center space-x-1.5 text-neutral-400 hover:text-white transition-colors border border-neutral-800 hover:border-neutral-600 bg-neutral-900/80 px-2.5 py-1 text-[11px] font-mono cursor-pointer"
                    title="Download full-resolution image with Chase Sutton signature logo watermark"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{isDownloading ? 'Watermarking...' : 'Download Image'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Right Information & Specs Panel */}
            <div className="lg:col-span-4 p-6 overflow-y-auto bg-[#0d0d0d] flex flex-col justify-between space-y-6">
              <div className="space-y-6">
                <div>
                  <div className="flex items-center space-x-2 text-xs font-mono text-neutral-500 mb-2">
                    <span className="uppercase tracking-widest text-neutral-400">{project.category}</span>
                    <span>/</span>
                    <span>{project.date}</span>
                    {(project.subtitle || project.koreanSub) && (
                      <>
                        <span>/</span>
                        <span className="text-white font-mono">{project.subtitle || project.koreanSub}</span>
                      </>
                    )}
                  </div>

                  <h2 className="font-['Cinzel'] text-2xl sm:text-3xl text-white font-bold tracking-tight uppercase">
                    {project.title}
                  </h2>
                </div>

                {/* Concept Narrative */}
                <div className="space-y-3">
                  <div className="text-xs font-mono text-neutral-400 uppercase tracking-widest flex items-center space-x-2">
                    <span>PROJECT OVERVIEW</span>
                  </div>
                  <p className="font-sans text-neutral-300 text-sm leading-relaxed">
                    {project.description}
                  </p>

                  {/* Flexible Notes */}
                  {project.notes && (
                    <div className="border-l-2 border-neutral-700 bg-neutral-900/50 p-3 text-xs font-mono text-neutral-400">
                      <span className="text-neutral-500 block text-[9px] uppercase tracking-wider mb-1">TECHNICAL NOTES</span>
                      {project.notes}
                    </div>
                  )}
                </div>

                {/* Technical Specifications Matrix: Objects, Vertices, Faces, Render Time, Engine */}
                <div className="space-y-3">
                  <div className="text-xs font-mono text-neutral-400 uppercase tracking-widest flex items-center justify-between">
                    <span>3D STATS & ENGINE</span>
                    <span className="text-[10px] text-neutral-500 font-mono">SPEC SHEET</span>
                  </div>

                  <div className="border border-neutral-800 bg-[#080808] divide-y divide-neutral-800 text-xs font-mono">
                    {project.stats.engine && (
                      <div className="p-2.5 flex justify-between">
                        <span className="text-neutral-500 uppercase">ENGINE</span>
                        <span className="text-white font-medium">{project.stats.engine}</span>
                      </div>
                    )}
                    {project.stats.objects && (
                      <div className="p-2.5 flex justify-between">
                        <span className="text-neutral-500 uppercase">OBJECTS</span>
                        <span className="text-white font-medium">{project.stats.objects}</span>
                      </div>
                    )}
                    {project.stats.vertices && (
                      <div className="p-2.5 flex justify-between">
                        <span className="text-neutral-500 uppercase">VERTICES</span>
                        <span className="text-white font-medium">{project.stats.vertices}</span>
                      </div>
                    )}
                    {project.stats.faces && (
                      <div className="p-2.5 flex justify-between">
                        <span className="text-neutral-500 uppercase">FACES</span>
                        <span className="text-white font-medium">{project.stats.faces}</span>
                      </div>
                    )}
                    {project.stats.renderTime && (
                      <div className="p-2.5 flex justify-between">
                        <span className="text-neutral-500 uppercase">RENDER TIME</span>
                        <span className="text-white font-medium">{project.stats.renderTime}</span>
                      </div>
                    )}

                    {/* Any custom extra stats */}
                    {Object.entries(project.stats)
                      .filter(([key]) => !['engine', 'objects', 'vertices', 'faces', 'renderTime'].includes(key))
                      .map(([key, val]) => (
                        <div key={key} className="p-2.5 flex justify-between">
                          <span className="text-neutral-500 uppercase">{key}</span>
                          <span className="text-white">{val}</span>
                        </div>
                      ))}
                  </div>
                </div>
              </div>

              {/* Share and Action Footer */}
              <div className="pt-6 border-t border-neutral-800 flex flex-col sm:flex-row items-center gap-3">
                {onSetFeatured && (
                  <button
                    onClick={() => onSetFeatured(project.id)}
                    className={`w-full sm:flex-1 border py-3 font-mono text-xs uppercase tracking-widest font-semibold flex items-center justify-center space-x-2 transition-colors ${
                      project.featured
                        ? 'bg-white text-black border-white'
                        : 'border-neutral-700 hover:border-white bg-[#141414] hover:bg-neutral-900 text-white'
                    }`}
                  >
                    <Star className={`w-4 h-4 ${project.featured ? 'fill-black text-black' : ''}`} />
                    <span>{project.featured ? 'Featured Project' : 'Make Featured'}</span>
                  </button>
                )}

                <button
                  onClick={handleShare}
                  className="w-full sm:flex-1 border border-neutral-700 hover:border-white bg-[#141414] hover:bg-neutral-900 py-3 font-mono text-xs uppercase tracking-widest font-semibold flex items-center justify-center space-x-2 transition-colors"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>URL Copied</span>
                    </>
                  ) : (
                    <>
                      <Share2 className="w-4 h-4" />
                      <span>Share Project</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
