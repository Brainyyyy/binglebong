import React from 'react';
import { ProjectItem } from '../types';
import { X, ArrowUp, ArrowDown, Check, GripVertical } from 'lucide-react';

interface ReorderModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: ProjectItem[];
  onSaveOrder: (newProjects: ProjectItem[]) => void;
}

export const ReorderModal: React.FC<ReorderModalProps> = ({
  isOpen,
  onClose,
  projects,
  onSaveOrder,
}) => {
  const [items, setItems] = React.useState<ProjectItem[]>(projects);

  React.useEffect(() => {
    setItems(projects);
  }, [projects, isOpen]);

  if (!isOpen) return null;

  const moveItem = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= items.length) return;
    const updated = [...items];
    const temp = updated[index];
    updated[index] = updated[newIndex];
    updated[newIndex] = temp;

    // Update index numbers to match new order
    const total = updated.length;
    const reindexed = updated.map((item, idx) => ({
      ...item,
      indexNumber: `${String(idx + 1).padStart(2, '0')} / ${String(total).padStart(2, '0')}`,
    }));

    setItems(reindexed);
  };

  const handleApply = () => {
    onSaveOrder(items);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4">
      <div className="w-full max-w-2xl bg-[#0c0c0c] border border-neutral-700 max-h-[85vh] flex flex-col overflow-hidden text-neutral-200 shadow-2xl">
        {/* Header */}
        <div className="h-14 border-b border-neutral-800 bg-[#080808] px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            <span className="font-mono text-xs font-bold text-white tracking-widest uppercase">
              REORDER PROJECTS
            </span>
            <span className="text-neutral-600">/</span>
            <span className="text-xs font-mono text-neutral-400">ARRANGE PORTFOLIO ORDER</span>
          </div>

          <button onClick={onClose} className="text-neutral-400 hover:text-white p-1 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Project List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-2">
          <p className="text-xs font-mono text-neutral-400 mb-4">
            Use the arrows to adjust the display sequence of projects across the Editorial and Grid views.
          </p>

          {items.map((project, idx) => (
            <div
              key={project.id}
              className="flex items-center justify-between p-3 border border-neutral-800 bg-[#121212] hover:border-neutral-600 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <span className="font-mono text-xs font-bold text-white w-8">
                  {String(idx + 1).padStart(2, '0')}
                </span>
                <div className="w-12 h-8 bg-black border border-neutral-800 overflow-hidden shrink-0">
                  <img src={project.imageUrl} alt="" className="w-full h-full object-cover" />
                </div>
                <div>
                  <h4 className="font-['Cinzel'] text-xs font-bold text-white tracking-wider uppercase">
                    {project.title}
                  </h4>
                  <span className="text-[10px] font-mono text-neutral-400">
                    {project.category} • {project.date}
                  </span>
                </div>
              </div>

              {/* Move Buttons */}
              <div className="flex items-center space-x-1.5">
                <button
                  type="button"
                  disabled={idx === 0}
                  onClick={() => moveItem(idx, 'up')}
                  className="p-1.5 border border-neutral-700 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white disabled:opacity-20 disabled:hover:text-neutral-400 transition-colors"
                  title="Move Up"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  disabled={idx === items.length - 1}
                  onClick={() => moveItem(idx, 'down')}
                  className="p-1.5 border border-neutral-700 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white disabled:opacity-20 disabled:hover:text-neutral-400 transition-colors"
                  title="Move Down"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="h-16 border-t border-neutral-800 bg-[#080808] px-6 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="border border-neutral-800 hover:border-neutral-600 px-4 py-2 text-xs font-mono uppercase text-neutral-400 hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleApply}
            className="border border-white bg-white text-black hover:bg-neutral-200 px-6 py-2 text-xs font-mono uppercase tracking-widest font-bold flex items-center space-x-2 transition-colors"
          >
            <Check className="w-4 h-4" />
            <span>Apply New Order</span>
          </button>
        </div>
      </div>
    </div>
  );
};
