import React, { useState, useEffect } from 'react';
import { ViewMode } from '../types';
import { Grid, Layers, Plus, ArrowUpDown } from 'lucide-react';
import { Logo } from './Logo';

interface HeaderProps {
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  projectCount: number;
  onOpenUpload: () => void;
  onOpenReorder?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  viewMode,
  onViewModeChange,
  projectCount,
  onOpenUpload,
  onOpenReorder,
}) => {
  const [localTime, setLocalTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setLocalTime(
        now.toLocaleTimeString([], {
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#080808]/95 backdrop-blur-md border-b border-neutral-800 text-neutral-300">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Left branding */}
        <div className="flex items-center space-x-6 shrink-0 min-w-0">
          <div
            className="flex items-center cursor-pointer select-none shrink-0 whitespace-nowrap"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            <Logo size="md" showText={true} />
          </div>

          <div className="hidden md:flex items-center space-x-4 border-l border-neutral-800 pl-6 text-xs font-mono text-neutral-400">
            <span className="text-neutral-500 tracking-wider">LOCAL TIME</span>
            <span className="text-white tracking-widest font-mono font-medium">{localTime || '00:00:00'}</span>
            <span className="text-neutral-700">|</span>
            <span className="text-neutral-500 tracking-wider">PROJECTS</span>
            <span className="text-neutral-200 font-mono">[{String(projectCount).padStart(2, '0')}]</span>
          </div>
        </div>

        {/* Center / Section links */}
        <nav className="hidden lg:flex items-center space-x-4 text-xs font-mono uppercase tracking-widest">
          <button
            onClick={() => scrollToSection('showcase-section')}
            className="text-neutral-400 hover:text-white transition-colors duration-150 py-1"
          >
            01 / Archive
          </button>
          <span className="text-neutral-700 select-none">/</span>
          <button
            onClick={() => scrollToSection('about-section')}
            className="text-neutral-400 hover:text-white transition-colors duration-150 py-1"
          >
            02 / About
          </button>
        </nav>

        {/* Right controls */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Reorder Button */}
          {onOpenReorder && (
            <button
              onClick={onOpenReorder}
              title="Reorder Projects"
              className="border border-neutral-800 bg-[#111111] hover:border-neutral-600 hover:bg-neutral-900 text-neutral-300 p-2 text-xs flex items-center space-x-1.5 transition-colors font-mono tracking-wider uppercase"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span className="hidden md:inline text-[10px]">Reorder</span>
            </button>
          )}

          {/* View mode toggle */}
          <div className="flex items-center border border-neutral-800 bg-[#111111]">
            <button
              onClick={() => onViewModeChange('editorial')}
              title="Editorial Flow View"
              className={`p-2 text-xs flex items-center space-x-1.5 transition-colors ${
                viewMode === 'editorial'
                  ? 'bg-white text-black font-semibold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span className="hidden sm:inline font-mono text-[10px] tracking-wider uppercase">Editorial</span>
            </button>
            <button
              onClick={() => onViewModeChange('grid')}
              title="Grid View"
              className={`p-2 text-xs flex items-center space-x-1.5 transition-colors ${
                viewMode === 'grid'
                  ? 'bg-white text-black font-semibold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
              <span className="hidden sm:inline font-mono text-[10px] tracking-wider uppercase">Grid</span>
            </button>
          </div>

          {/* Add 3D Project Button */}
          <button
            onClick={onOpenUpload}
            className="border border-white bg-white text-black hover:bg-neutral-200 font-mono text-[11px] font-bold px-3 py-2 flex items-center space-x-1.5 tracking-wider uppercase transition-colors"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span className="hidden sm:inline">Add Project</span>
          </button>
        </div>
      </div>
    </header>
  );
};
