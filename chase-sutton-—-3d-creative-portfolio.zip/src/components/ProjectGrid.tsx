import React from 'react';
import { motion } from 'motion/react';
import { ProjectItem } from '../types';
import { Maximize2, ArrowUpRight, Edit3, Trash2, Star } from 'lucide-react';

interface ProjectGridProps {
  projects: ProjectItem[];
  onInspectProject: (project: ProjectItem) => void;
  activeCategory: string;
  onSelectCategory: (category: string) => void;
  onEditProject?: (project: ProjectItem) => void;
  onDeleteProject?: (id: string) => void;
  onSetFeatured?: (id: string) => void;
}

export const ProjectGrid: React.FC<ProjectGridProps> = ({
  projects,
  onInspectProject,
  activeCategory,
  onSelectCategory,
  onEditProject,
  onDeleteProject,
  onSetFeatured,
}) => {
  const categories = ['ALL', 'Characters', 'Environments', 'Architecture', 'Objects'];

  const filteredProjects = activeCategory === 'ALL'
    ? projects
    : projects.filter((p) => p.category.toLowerCase() === activeCategory.toLowerCase());

  return (
    <section id="showcase-section" className="pt-20 pb-12 border-b border-neutral-800 bg-[#0a0a0a]">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header & Filter */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-neutral-800 pb-6 mb-12 gap-6">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-neutral-400 mb-2">
              <span className="uppercase tracking-widest text-white font-semibold">01 // ARCHIVE</span>
              <span className="text-neutral-600">/</span>
              <span className="tracking-widest uppercase text-neutral-400">3D CREATIVE WORKS</span>
            </div>
            <h2 className="font-['Cinzel'] text-3xl sm:text-5xl text-white uppercase tracking-tight font-bold">
              PROJECT CATALOG
            </h2>
            <p className="font-mono text-xs text-neutral-400 mt-1 tracking-wider uppercase">
              Full Portfolio Grid // Selected Works
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-1 border border-neutral-800 p-1 bg-[#111111]">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => onSelectCategory(cat)}
                className={`font-mono text-[11px] tracking-wider uppercase px-3 py-1.5 transition-colors ${
                  activeCategory === cat
                    ? 'bg-white text-black font-bold'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Sharp Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project, idx) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: idx * 0.05 }}
              className="group border border-neutral-800 bg-[#0d0d0d] relative hover:border-neutral-500 transition-all duration-300 flex flex-col shadow-xl"
            >
              {/* Corner Reticle Crosshairs */}
              <div className="absolute -top-1.5 -left-1.5 text-neutral-600 group-hover:text-white text-[10px] font-mono select-none pointer-events-none">
                +
              </div>
              <div className="absolute -top-1.5 -right-1.5 text-neutral-600 group-hover:text-white text-[10px] font-mono select-none pointer-events-none">
                +
              </div>
              <div className="absolute -bottom-1.5 -left-1.5 text-neutral-600 group-hover:text-white text-[10px] font-mono select-none pointer-events-none">
                +
              </div>
              <div className="absolute -bottom-1.5 -right-1.5 text-neutral-600 group-hover:text-white text-[10px] font-mono select-none pointer-events-none">
                +
              </div>

              {/* Top Meta Bar */}
              <div className="border-b border-neutral-800 px-4 py-2.5 flex items-center justify-between text-xs font-mono bg-[#0a0a0a]">
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-white tracking-widest">{project.indexNumber}</span>
                  <span className="text-neutral-600">|</span>
                  <span className="text-[10px] text-neutral-400 uppercase tracking-widest font-mono">
                    {project.subtitle || project.koreanSub || project.category}
                  </span>
                  {project.featured && (
                    <span className="px-1.5 py-0.5 bg-white text-black text-[8px] font-bold uppercase tracking-wider">
                      FEATURED
                    </span>
                  )}
                </div>
                
                <div className="flex items-center space-x-2">
                  {onSetFeatured && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSetFeatured(project.id);
                      }}
                      title={project.featured ? "Currently featured in hero" : "Make this the featured project"}
                      className={`transition-colors p-0.5 ${
                        project.featured
                          ? 'text-white'
                          : 'text-neutral-600 hover:text-white'
                      }`}
                    >
                      <Star className={`w-3 h-3 ${project.featured ? 'fill-white text-white' : ''}`} />
                    </button>
                  )}
                  {onEditProject && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onEditProject(project);
                      }}
                      title="Edit project"
                      className="text-neutral-500 hover:text-white transition-colors p-0.5"
                    >
                      <Edit3 className="w-3 h-3" />
                    </button>
                  )}
                  {onDeleteProject && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteProject(project.id);
                      }}
                      title="Delete project"
                      className="text-neutral-600 hover:text-red-400 transition-colors p-0.5"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                  <button
                    onClick={() => onInspectProject(project)}
                    title="Inspect project"
                    className="text-neutral-500 group-hover:text-white transition-colors"
                  >
                    <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </button>
                </div>
              </div>

              {/* Image Viewport - FULL COLOR (no grayscale!) */}
              <div 
                className="aspect-[4/3] w-full overflow-hidden relative bg-black cursor-pointer"
                onClick={() => onInspectProject(project)}
              >
                <img
                  src={project.imageUrl}
                  alt={project.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60 group-hover:opacity-20 transition-opacity" />

                {/* Bottom Overlay: CHANGED FROM CAMERA SPECS TO DATE OF THE PROJECT */}
                <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
                  <div className="font-mono text-[10px] text-white bg-black/85 px-2.5 py-1 border border-neutral-700 tracking-wider">
                    {project.date}
                  </div>
                  <div className="bg-white text-black p-1.5 opacity-0 group-hover:opacity-100 transition-opacity shadow-md">
                    <Maximize2 className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>

              {/* Bottom Details */}
              <div 
                className="p-4 flex-1 flex flex-col justify-between bg-[#0e0e0e] cursor-pointer"
                onClick={() => onInspectProject(project)}
              >
                <div>
                  <h3 className="font-['Cinzel'] text-lg text-white font-bold tracking-tight uppercase group-hover:text-neutral-200 transition-colors">
                    {project.title}
                  </h3>
                  <p className="mt-2 font-sans text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                    {project.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-[10px] font-mono text-neutral-400">
                  <span className="truncate max-w-[140px] text-neutral-500">
                    {project.stats.engine || project.category}
                  </span>
                  <span className="text-neutral-300">
                    {project.stats.faces ? `F: ${project.stats.faces}` : project.stats.vertices ? `V: ${project.stats.vertices}` : project.date}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
