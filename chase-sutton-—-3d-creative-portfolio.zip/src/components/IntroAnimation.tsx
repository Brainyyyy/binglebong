import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface IntroAnimationProps {
  onComplete: () => void;
}

export const IntroAnimation: React.FC<IntroAnimationProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    // Smooth, cinematic progress bar over 2.4s
    const startTime = Date.now();
    const duration = 2400; // ms

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);

      if (pct >= 100) {
        clearInterval(interval);
        // Begin exit sequence
        setIsExiting(true);
        setTimeout(() => {
          onComplete();
        }, 600);
      }
    }, 20);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === ' ' || e.key === 'Enter') {
        clearInterval(interval);
        onComplete();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      clearInterval(interval);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onComplete]);

  const handleSkip = () => {
    onComplete();
  };

  return (
    <AnimatePresence>
      {!isExiting && (
        <motion.div
          key="intro-curtain"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.02 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          onClick={handleSkip}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#050505] text-white cursor-pointer select-none overflow-hidden"
        >
          {/* Subtle background tech grid */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#111111_1px,transparent_1px),linear-gradient(to_bottom,#111111_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-30 pointer-events-none" />

          {/* Centerpiece Container */}
          <div className="relative z-10 flex flex-col items-center max-w-sm w-full px-6">
            {/* Circular Logo with Concentric Framing Ring */}
            <div className="relative flex items-center justify-center mb-8">
              {/* Rotating outer compass ring */}
              <motion.div
                initial={{ rotate: 0, opacity: 0 }}
                animate={{ rotate: 180, opacity: 0.5 }}
                transition={{ duration: 1.6, ease: 'easeOut' }}
                className="absolute -inset-4 border border-dashed border-neutral-700 rounded-full"
              />

              {/* Glowing subtle ring */}
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 0.3 }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
                className="absolute -inset-1.5 border border-white/20 rounded-full"
              />

              {/* The User's Circular Logo (DesignLogoSmall.png) */}
              <motion.div
                initial={{ scale: 0.85, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden border border-neutral-700 bg-black shadow-[0_0_35px_rgba(255,255,255,0.06)] shrink-0"
              >
                <img
                  src="/DesignLogoSmall.png"
                  alt="Chase Sutton"
                  className="w-full h-full object-cover block"
                />
              </motion.div>
            </div>

            {/* Typography: CHASE SUTTON with tracking expansion */}
            <motion.div
              initial={{ y: 8, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.6, ease: 'easeOut' }}
              className="text-center"
            >
              <h1 className="font-['Cinzel'] font-bold text-2xl sm:text-3xl text-white tracking-[0.25em] uppercase whitespace-nowrap">
                CHASE SUTTON
              </h1>
              <div className="mt-2 flex items-center justify-center space-x-2 text-[10px] font-mono text-neutral-400 tracking-[0.2em] uppercase">
                <span>3D CREATIVE ARCHIVE</span>
                <span className="text-neutral-700">•</span>
                <span className="text-neutral-400">BLENDER</span>
              </div>
            </motion.div>

            {/* Progress Rule & Readout */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.4 }}
              className="w-48 sm:w-56 mt-8"
            >
              {/* Progress track */}
              <div className="h-[2px] w-full bg-neutral-900 overflow-hidden relative border border-neutral-800/80">
                <div
                  className="h-full bg-white transition-all duration-75 ease-out"
                  style={{ width: `${progress}%` }}
                />
              </div>

              {/* Progress metrics */}
              <div className="mt-2.5 flex items-center justify-between text-[9px] font-mono text-neutral-400">
                <span className="tracking-widest uppercase">SYS.INITIALIZE</span>
                <span className="font-medium text-white">{progress}%</span>
              </div>
            </motion.div>
          </div>

          {/* Bottom helper prompt */}
          <div className="absolute bottom-6 left-0 right-0 text-center pointer-events-none">
            <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest">
              CLICK OR PRESS ESC TO SKIP
            </span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
