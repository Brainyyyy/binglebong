import React from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { ProjectItem } from '../types';
import { ArrowDown, Maximize2 } from 'lucide-react';

interface HeroProps {
  featuredProject: ProjectItem;
  onInspectProject: (project: ProjectItem) => void;
  totalProjects: number;
}

export const Hero: React.FC<HeroProps> = ({
  featuredProject,
  onInspectProject,
  totalProjects
}) => {
  const { scrollY } = useScroll();
  const imageY = useTransform(scrollY, [0, 600], [0, 80]);
  const imageScale = useTransform(scrollY, [0, 600], [1, 1.04]);
  const opacity = useTransform(scrollY, [0, 500], [1, 0.25]);

  return (
    <section className="relative min-h-screen pt-20 pb-16 flex flex-col justify-between border-b border-neutral-800 overflow-hidden bg-[#080808]">
      {/* Background Subtle Grid Lines */}
      <div className="absolute inset-0 pointer-events-none bg-grid-subtle opacity-35" />

      {/* Top Editorial Bar */}
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="flex flex-wrap items-center justify-between border-b border-neutral-800/80 pb-4 text-xs font-mono text-neutral-400 gap-4">
          <div className="flex items-center space-x-3">
            <span className="text-white tracking-widest font-mono">36° 50' 54" S, 174° 45' 48" E</span>
            <span className="text-neutral-600">/</span>
            <span className="text-neutral-300 tracking-wider">3D Project Archive</span>
          </div>

          <div className="flex items-center space-x-6">
            <span className="text-neutral-500 uppercase tracking-widest">EST. 2020 — PRESENT</span>
            <span className="text-neutral-600">|</span>
            <span className="text-white tracking-widest uppercase">3D CREATIVE STUDIO</span>
          </div>
        </div>
      </div>

      {/* Center Cinematic Display & Hero Headline */}
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12 my-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-end">
          {/* Main Typography Column */}
          <motion.div 
            style={{ opacity }}
            className="lg:col-span-6 flex flex-col justify-end"
          >
            <div className="mb-3 flex items-center space-x-3">
              <span className="font-mono text-xs tracking-[0.25em] text-neutral-400 uppercase">
                {(featuredProject.subtitle || featuredProject.koreanSub || '3D CREATIVE ARCHIVE (01)')
                  .replace(/\bstudy\b/gi, '')
                  .replace(/\s{2,}/g, ' ')
                  .trim()}
              </span>
              <div className="h-[1px] w-12 bg-neutral-700" />
              <span className="font-mono text-[10px] text-neutral-400 uppercase tracking-wider">
                {featuredProject.category}
              </span>
            </div>

            {/* Giant Monolithic Title: CHASE SUTTON */}
            <h1 className="font-['Cinzel'] text-5xl sm:text-7xl xl:text-8xl text-white tracking-tight leading-[0.9] uppercase select-none font-bold">
              CHASE<br />SUTTON
            </h1>

            <p className="mt-4 font-sans text-neutral-400 text-sm sm:text-base leading-relaxed max-w-lg">
              An archive documenting the development of my 3D projects created over the past 6 years. Featuring renders ranging from landscapes and architecture to detailed objects, all created in Blender.
            </p>

            {/* Quick Stats Banner from featured project */}
            <div className="mt-6 grid grid-cols-3 gap-2 border border-neutral-800 bg-[#0d0d0d] p-3 text-[11px] font-mono">
              {featuredProject.stats.engine && (
                <div>
                  <span className="text-neutral-500 block text-[9px] uppercase tracking-wider">ENGINE</span>
                  <span className="text-white font-medium truncate block">{featuredProject.stats.engine}</span>
                </div>
              )}
              {featuredProject.stats.vertices && (
                <div>
                  <span className="text-neutral-500 block text-[9px] uppercase tracking-wider">VERTICES</span>
                  <span className="text-white font-medium block">{featuredProject.stats.vertices}</span>
                </div>
              )}
              {featuredProject.stats.renderTime && (
                <div>
                  <span className="text-neutral-500 block text-[9px] uppercase tracking-wider">RENDER TIME</span>
                  <span className="text-white font-medium block">{featuredProject.stats.renderTime}</span>
                </div>
              )}
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-4 text-xs font-mono">
              <button
                onClick={() => onInspectProject(featuredProject)}
                className="border border-white bg-white text-black px-6 py-3 font-bold uppercase tracking-widest hover:bg-neutral-200 transition-colors flex items-center space-x-2"
              >
                <span>Inspect Featured [{featuredProject.indexNumber}]</span>
                <Maximize2 className="w-3.5 h-3.5" />
              </button>

              <div className="border border-neutral-800 px-4 py-3 bg-[#0d0d0d] text-neutral-400 flex items-center space-x-3">
                <span className="w-2 h-2 bg-emerald-500" />
                <span className="tracking-wider uppercase text-[11px]">{featuredProject.date}</span>
              </div>
            </div>
          </motion.div>

          {/* Featured Visual Framing (Full Color, Sharp Edge Box with Parallax) */}
          <div className="lg:col-span-6 relative">
            <motion.div 
              style={{ y: imageY, scale: imageScale }}
              className="relative border border-neutral-700 bg-neutral-900 group cursor-pointer overflow-hidden shadow-2xl"
              onClick={() => onInspectProject(featuredProject)}
            >
              {/* Image Frame - NOT black and white! Full vibrant colors! */}
              <div className="aspect-[16/10] sm:aspect-[16/9] w-full overflow-hidden relative">
                <img
                  src={featuredProject.imageUrl}
                  alt={featuredProject.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-all duration-700"
                />

                {/* Corner Crosshair Reticles (Sharp Graphic HUD) */}
                <div className="absolute top-2 left-2 font-mono text-[9px] text-white/80 bg-black/80 px-2 py-0.5 border border-white/20 uppercase tracking-wider">
                  REF. {featuredProject.indexNumber}
                </div>
                <div className="absolute top-2 right-2 font-mono text-[9px] text-white/80 bg-black/80 px-2 py-0.5 border border-white/20 uppercase tracking-wider">
                  {featuredProject.date}
                </div>
                <div className="absolute bottom-2 left-2 font-mono text-[10px] text-white bg-black/85 px-2.5 py-1 border border-neutral-700 flex items-center space-x-2">
                  <span className="font-bold tracking-wider uppercase">{featuredProject.title}</span>
                  <span className="text-neutral-500">|</span>
                  <span className="text-neutral-400">{featuredProject.category}</span>
                </div>
                <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-white text-black p-2">
                  <Maximize2 className="w-4 h-4" />
                </div>
              </div>

              {/* Technical Sub-hud under frame */}
              <div className="border-t border-neutral-800 bg-[#0f0f0f] px-4 py-2.5 flex items-center justify-between text-[11px] font-mono text-neutral-400">
                <span>OBJ: {featuredProject.stats.objects || 'N/A'}</span>
                <span className="text-neutral-700">/</span>
                <span>FACES: {featuredProject.stats.faces || 'N/A'}</span>
                <span className="text-neutral-700">/</span>
                <span className="text-white">SHADING: RENDER</span>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Bottom Scroll HUD */}
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <div className="border-t border-neutral-800/80 pt-4 flex items-center justify-between text-xs font-mono text-neutral-500">
          <div className="flex items-center space-x-2">
            <span className="animate-pulse w-1.5 h-1.5 bg-white" />
            <span className="tracking-[0.2em] uppercase text-neutral-400">SCROLL TO EXPLORE ARCHIVE</span>
          </div>

          <div className="flex items-center space-x-4">
            <span className="text-neutral-400 font-mono tracking-widest">[ 01 / {String(totalProjects).padStart(2, '0')} ]</span>
            <a
              href="#showcase-section"
              className="border border-neutral-800 p-2 text-neutral-400 hover:text-white hover:border-neutral-600 transition-colors"
              aria-label="Scroll to showcase"
            >
              <ArrowDown className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
