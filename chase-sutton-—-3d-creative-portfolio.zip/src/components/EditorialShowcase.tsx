import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ProjectItem, ShaderType } from '../types';
import { Maximize2, Edit3, Trash2, ArrowUp, ArrowDown, Info, Star } from 'lucide-react';

interface EditorialShowcaseProps {
  projects: ProjectItem[];
  onInspectProject: (project: ProjectItem) => void;
  activeCategory: string;
  onSelectCategory: (category: string) => void;
  onEditProject?: (project: ProjectItem) => void;
  onDeleteProject?: (id: string) => void;
  onMoveProject?: (index: number, direction: 'up' | 'down') => void;
  onSetFeatured?: (id: string) => void;
}

export const EditorialShowcase: React.FC<EditorialShowcaseProps> = ({
  projects,
  onInspectProject,
  activeCategory,
  onSelectCategory,
  onEditProject,
  onDeleteProject,
  onMoveProject,
  onSetFeatured,
}) => {
  // Local shader selection per project id
  const [selectedShaders, setSelectedShaders] = useState<Record<string, ShaderType>>({});

  const categories = ['ALL', 'Characters', 'Environments', 'Architecture', 'Objects'];

  const filteredProjects = activeCategory === 'ALL'
    ? projects
    : projects.filter((p) => p.category.toLowerCase() === activeCategory.toLowerCase());

  // Helper to determine available shader options for a specific project
  const getAvailableShaders = (project: ProjectItem): ShaderType[] => {
    const shaders: ShaderType[] = ['Render'];
    if (project.solidUrl) shaders.push('Solid');
    if (project.wireframeUrl) shaders.push('Wireframe');
    return shaders;
  };

  // Helper to get image for active shader
  const getActiveImage = (project: ProjectItem, shader: ShaderType): string => {
    if (shader === 'Solid' && project.solidUrl) return project.solidUrl;
    if (shader === 'Wireframe' && project.wireframeUrl) return project.wireframeUrl;
    return project.imageUrl;
  };

  return (
    <section id="showcase-section" className="pt-20 pb-12 border-b border-neutral-800 bg-[#0a0a0a] relative">
      {/* Category Filter & Header Bar */}
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-neutral-800 pb-6 gap-6">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-neutral-400 mb-2">
              <span className="tracking-widest uppercase text-white font-semibold">01 // ARCHIVE</span>
              <span className="text-neutral-600">/</span>
              <span className="tracking-widest uppercase text-neutral-400">SELECTED 3D WORKS</span>
            </div>
            <h2 className="font-['Cinzel'] text-3xl sm:text-5xl text-white uppercase tracking-tight font-bold">
              3D PROJECT ARCHIVE
            </h2>
            <p className="font-mono text-xs text-neutral-400 mt-1 tracking-wider uppercase">
              Curated 3D Models // Shading & Wireframe Archive
            </p>
          </div>

          {/* Category Filter Buttons */}
          <div className="flex flex-wrap items-center gap-1 border border-neutral-800 p-1 bg-[#111111]">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => onSelectCategory(cat)}
                className={`font-mono text-[11px] tracking-wider uppercase px-3 py-1.5 transition-colors ${
                  activeCategory === cat
                    ? 'bg-white text-black font-bold'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Editorial Projects Staggered Stream */}
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24">
        {filteredProjects.map((project, idx) => {
          const availableShaders = getAvailableShaders(project);
          const currentShader = selectedShaders[project.id] || 'Render';
          const activeShader = availableShaders.includes(currentShader) ? currentShader : 'Render';
          const activeImage = getActiveImage(project, activeShader);
          const isReversed = idx % 2 === 1;

          // Find original index in full projects array for reordering
          const fullIndex = projects.findIndex((p) => p.id === project.id);

          return (
            <motion.article
              key={project.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="border border-neutral-800 bg-[#0d0d0d] overflow-hidden shadow-2xl"
            >
              {/* Top Card HUD bar */}
              <div className="border-b border-neutral-800 px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between text-xs font-mono text-neutral-400 gap-3 bg-[#0c0c0c]">
                <div className="flex items-center space-x-3">
                  <span className="font-bold text-white tracking-widest">{project.indexNumber}</span>
                  <span className="text-neutral-600">|</span>
                  <span className="text-neutral-300 tracking-wider uppercase font-mono">
                    {project.subtitle || project.koreanSub || project.category}
                  </span>
                  <span className="text-neutral-600">|</span>
                  <span className="text-neutral-400">{project.date}</span>
                  {project.featured && (
                    <>
                      <span className="text-neutral-600">|</span>
                      <span className="px-2 py-0.5 bg-white text-black font-bold text-[9px] uppercase tracking-widest flex items-center space-x-1">
                        <Star className="w-2.5 h-2.5 fill-black text-black" />
                        <span>FEATURED</span>
                      </span>
                    </>
                  )}
                </div>

                {/* Shader Viewport Switcher - Only shows options that exist! */}
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-1 border border-neutral-800 bg-[#141414] p-0.5">
                    <span className="px-2 text-[10px] text-neutral-500 uppercase tracking-widest hidden sm:inline">
                      SHADER:
                    </span>
                    {availableShaders.length === 1 ? (
                      <span className="px-2 py-0.5 text-[10px] uppercase font-mono bg-neutral-800 text-neutral-200">
                        {availableShaders[0]}
                      </span>
                    ) : (
                      availableShaders.map((shader) => (
                        <button
                          key={shader}
                          onClick={() => setSelectedShaders((prev) => ({ ...prev, [project.id]: shader }))}
                          className={`px-2.5 py-0.5 text-[10px] uppercase font-mono transition-colors ${
                            activeShader === shader
                              ? 'bg-white text-black font-bold'
                              : 'text-neutral-400 hover:text-white'
                          }`}
                        >
                          {shader}
                        </button>
                      ))
                    )}
                  </div>

                  {/* Project Reorder & Actions */}
                  <div className="flex items-center space-x-1 border-l border-neutral-800 pl-2">
                    {onMoveProject && fullIndex >= 0 && (
                      <>
                        <button
                          onClick={() => onMoveProject(fullIndex, 'up')}
                          disabled={fullIndex === 0}
                          title="Move project up in order"
                          className="p-1 text-neutral-400 hover:text-white disabled:opacity-20 disabled:hover:text-neutral-400 transition-colors"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onMoveProject(fullIndex, 'down')}
                          disabled={fullIndex === projects.length - 1}
                          title="Move project down in order"
                          className="p-1 text-neutral-400 hover:text-white disabled:opacity-20 disabled:hover:text-neutral-400 transition-colors"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}

                    {onSetFeatured && (
                      <button
                        onClick={() => onSetFeatured(project.id)}
                        title={project.featured ? "Currently featured in hero" : "Make this the featured project"}
                        className={`p-1 transition-colors ${
                          project.featured
                            ? 'text-white'
                            : 'text-neutral-500 hover:text-white'
                        }`}
                      >
                        <Star className={`w-3.5 h-3.5 ${project.featured ? 'fill-white text-white' : ''}`} />
                      </button>
                    )}

                    {onEditProject && (
                      <button
                        onClick={() => onEditProject(project)}
                        title="Edit project details"
                        className="p-1 text-neutral-400 hover:text-white transition-colors"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {onDeleteProject && (
                      <button
                        onClick={() => onDeleteProject(project.id)}
                        title="Delete project"
                        className="p-1 text-neutral-500 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Main Content Layout */}
              <div className={`grid grid-cols-1 lg:grid-cols-12 gap-0 ${isReversed ? 'lg:flex-row-reverse' : ''}`}>
                {/* Visual Viewport - Full Color (NO grayscale) */}
                <div className="lg:col-span-8 relative border-b lg:border-b-0 lg:border-r border-neutral-800 bg-black group overflow-hidden">
                  <div className="aspect-[16/10] w-full relative overflow-hidden bg-black">
                    <AnimatePresence mode="wait">
                      <motion.img
                        key={activeImage}
                        src={activeImage}
                        alt={`${project.title} - ${activeShader}`}
                        referrerPolicy="no-referrer"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.25, ease: 'easeInOut' }}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-103"
                      />
                    </AnimatePresence>

                    {/* Reticle HUD overlay */}
                    <div className="absolute top-3 left-3 bg-black/85 border border-neutral-700 px-2.5 py-1 text-[10px] font-mono text-neutral-300">
                      VIEW: {activeShader.toUpperCase()}
                    </div>

                    <div className="absolute bottom-3 right-3 flex items-center space-x-2">
                      <button
                        onClick={() => onInspectProject(project)}
                        className="bg-white text-black hover:bg-neutral-200 px-3 py-1.5 font-mono text-xs font-bold uppercase tracking-wider flex items-center space-x-1.5 transition-colors shadow-lg"
                      >
                        <Maximize2 className="w-3.5 h-3.5" />
                        <span>Inspect Full</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Editorial Details Column */}
                <div className="lg:col-span-4 p-6 sm:p-8 flex flex-col justify-between bg-[#0e0e0e]">
                  <div>
                    <div className="flex items-center space-x-2 text-xs font-mono text-neutral-500 mb-2">
                      <span className="uppercase tracking-widest text-neutral-400">{project.category}</span>
                      <span>—</span>
                      <span>{project.date}</span>
                    </div>

                    <h3 className="font-['Cinzel'] text-2xl sm:text-3xl text-white font-bold tracking-tight uppercase mb-4">
                      {project.title}
                    </h3>

                    <p className="font-sans text-neutral-300 text-sm leading-relaxed mb-6">
                      {project.description}
                    </p>

                    {project.notes && (
                      <div className="border-l-2 border-neutral-600 pl-3 py-1 text-xs font-mono text-neutral-400 mb-6 bg-neutral-900/30">
                        {project.notes}
                      </div>
                    )}
                  </div>

                  {/* Technical Stats HUD Box (Objects, Vertices, Faces, Render Time, Engine) */}
                  <div className="border border-neutral-800 bg-[#090909] p-4 text-xs font-mono space-y-2 mt-4">
                    <div className="text-[10px] text-neutral-500 uppercase tracking-widest border-b border-neutral-800 pb-1 flex items-center justify-between">
                      <span>3D STATS</span>
                      <span className="text-white">PROJECT SPECS</span>
                    </div>

                    {project.stats.engine && (
                      <div className="flex justify-between text-neutral-400 text-[11px]">
                        <span className="text-neutral-500">ENGINE</span>
                        <span className="text-neutral-200">{project.stats.engine}</span>
                      </div>
                    )}
                    {project.stats.objects && (
                      <div className="flex justify-between text-neutral-400 text-[11px]">
                        <span className="text-neutral-500">OBJECTS</span>
                        <span className="text-neutral-200">{project.stats.objects}</span>
                      </div>
                    )}
                    {project.stats.vertices && (
                      <div className="flex justify-between text-neutral-400 text-[11px]">
                        <span className="text-neutral-500">VERTICES</span>
                        <span className="text-neutral-200">{project.stats.vertices}</span>
                      </div>
                    )}
                    {project.stats.faces && (
                      <div className="flex justify-between text-neutral-400 text-[11px]">
                        <span className="text-neutral-500">FACES</span>
                        <span className="text-neutral-200">{project.stats.faces}</span>
                      </div>
                    )}
                    {project.stats.renderTime && (
                      <div className="flex justify-between text-neutral-400 text-[11px]">
                        <span className="text-neutral-500">RENDER TIME</span>
                        <span className="text-neutral-200">{project.stats.renderTime}</span>
                      </div>
                    )}

                    {/* Custom dynamic extra stats if present */}
                    {Object.entries(project.stats)
                      .filter(([key]) => !['engine', 'objects', 'vertices', 'faces', 'renderTime'].includes(key))
                      .map(([key, val]) => (
                        <div key={key} className="flex justify-between text-neutral-400 text-[11px]">
                          <span className="text-neutral-500 uppercase">{key}</span>
                          <span className="text-neutral-200">{val}</span>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </motion.article>
          );
        })}
      </div>
    </section>
  );
};
