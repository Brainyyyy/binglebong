/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ProjectItem, ViewMode } from './types';
import { getStoredProjects, saveStoredProjects } from './data/projects';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { EditorialShowcase } from './components/EditorialShowcase';
import { ProjectGrid } from './components/ProjectGrid';
import { ProjectInspectorModal } from './components/ProjectInspectorModal';
import { ProjectEditorModal } from './components/ProjectEditorModal';
import { ReorderModal } from './components/ReorderModal';
import { AboutSection } from './components/AboutSection';
import { Footer } from './components/Footer';
import { IntroAnimation } from './components/IntroAnimation';

export default function App() {
  const [projects, setProjects] = useState<ProjectItem[]>(() => getStoredProjects());
  const [viewMode, setViewMode] = useState<ViewMode>('editorial');
  const [activeCategory, setActiveCategory] = useState<string>('ALL');
  const [showIntro, setShowIntro] = useState<boolean>(true);
  
  // Modals
  const [inspectedProject, setInspectedProject] = useState<ProjectItem | null>(null);
  const [editingProject, setEditingProject] = useState<ProjectItem | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState<boolean>(false);
  const [isReorderOpen, setIsReorderOpen] = useState<boolean>(false);

  // Sync to local storage whenever projects change
  useEffect(() => {
    saveStoredProjects(projects);
  }, [projects]);

  // Keep inspected project in sync if updated
  useEffect(() => {
    if (inspectedProject) {
      const updated = projects.find((p) => p.id === inspectedProject.id);
      if (updated) {
        setInspectedProject(updated);
      } else {
        setInspectedProject(null);
      }
    }
  }, [projects]);

  // Open editor for adding new project
  const handleOpenAdd = () => {
    setEditingProject(null);
    setIsEditorOpen(true);
  };

  // Open editor for modifying existing project
  const handleOpenEdit = (project: ProjectItem) => {
    setEditingProject(project);
    setIsEditorOpen(true);
  };

  // Save project (either add or update)
  const handleSaveProject = (savedProject: ProjectItem) => {
    setProjects((prev) => {
      let updated: ProjectItem[];
      const existingIndex = prev.findIndex((p) => p.id === savedProject.id);
      if (existingIndex >= 0) {
        // Update in place
        const copy = [...prev];
        copy[existingIndex] = savedProject;
        updated = copy;
      } else {
        // Add to front of list and update index numbers
        const updatedList = [savedProject, ...prev];
        const total = updatedList.length;
        updated = updatedList.map((item, idx) => ({
          ...item,
          indexNumber: `${String(idx + 1).padStart(2, '0')} / ${String(total).padStart(2, '0')}`,
        }));
      }

      // If saved project is featured, ensure other projects are not featured
      if (savedProject.featured) {
        updated = updated.map((p) => ({
          ...p,
          featured: p.id === savedProject.id,
        }));
      }

      return updated;
    });

    // Also view it in inspector if added or updated
    setInspectedProject(savedProject);
  };

  // Set single featured project
  const handleSetFeaturedProject = (id: string) => {
    setProjects((prev) =>
      prev.map((p) => ({
        ...p,
        featured: p.id === id,
      }))
    );
    setInspectedProject((current) => {
      if (!current) return null;
      return {
        ...current,
        featured: current.id === id,
      };
    });
  };

  // Delete project
  const handleDeleteProject = (id: string) => {
    setProjects((prev) => {
      const filtered = prev.filter((p) => p.id !== id);
      const total = filtered.length;
      return filtered.map((item, idx) => ({
        ...item,
        indexNumber: `${String(idx + 1).padStart(2, '0')} / ${String(total).padStart(2, '0')}`,
      }));
    });
    if (inspectedProject?.id === id) {
      setInspectedProject(null);
    }
  };

  // Move project up or down
  const handleMoveProject = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= projects.length) return;

    const copy = [...projects];
    const temp = copy[index];
    copy[index] = copy[newIndex];
    copy[newIndex] = temp;

    const total = copy.length;
    const reindexed = copy.map((item, idx) => ({
      ...item,
      indexNumber: `${String(idx + 1).padStart(2, '0')} / ${String(total).padStart(2, '0')}`,
    }));

    setProjects(reindexed);
  };

  // Apply reorder from modal
  const handleSaveReordered = (reorderedProjects: ProjectItem[]) => {
    setProjects(reorderedProjects);
  };

  // Navigate between projects in inspector
  const handleNavigateProject = (direction: 'next' | 'prev') => {
    if (!inspectedProject) return;
    const currentIndex = projects.findIndex((p) => p.id === inspectedProject.id);
    if (currentIndex === -1) return;

    if (direction === 'next') {
      const nextIndex = (currentIndex + 1) % projects.length;
      setInspectedProject(projects[nextIndex]);
    } else {
      const prevIndex = (currentIndex - 1 + projects.length) % projects.length;
      setInspectedProject(projects[prevIndex]);
    }
  };

  const featured = projects.find((p) => p.featured) || projects[0] || {
    id: 'placeholder',
    title: 'CHASE SUTTON ARCHIVE',
    category: 'Characters',
    date: '2024',
    indexNumber: '01 / 01',
    aspectRatio: '16:9',
    imageUrl: '',
    description: 'No projects loaded.',
    stats: {},
  };

  return (
    <div className="relative min-h-screen bg-[#080808] text-[#e5e5e5] flex flex-col font-sans selection:bg-white selection:text-black">
      {/* Intro Animation on page load */}
      {showIntro && (
        <IntroAnimation onComplete={() => setShowIntro(false)} />
      )}

      {/* Header */}
      <Header
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        projectCount={projects.length}
        onOpenUpload={handleOpenAdd}
        onOpenReorder={() => setIsReorderOpen(true)}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section */}
        {projects.length > 0 && (
          <Hero
            featuredProject={featured}
            onInspectProject={setInspectedProject}
            totalProjects={projects.length}
          />
        )}

        {/* Dynamic Gallery: Editorial Staggered Flow vs. 3D Project Grid */}
        {viewMode === 'editorial' ? (
          <EditorialShowcase
            projects={projects}
            onInspectProject={setInspectedProject}
            activeCategory={activeCategory}
            onSelectCategory={setActiveCategory}
            onEditProject={handleOpenEdit}
            onDeleteProject={handleDeleteProject}
            onMoveProject={handleMoveProject}
            onSetFeatured={handleSetFeaturedProject}
          />
        ) : (
          <ProjectGrid
            projects={projects}
            onInspectProject={setInspectedProject}
            activeCategory={activeCategory}
            onSelectCategory={setActiveCategory}
            onEditProject={handleOpenEdit}
            onDeleteProject={handleDeleteProject}
            onSetFeatured={handleSetFeaturedProject}
          />
        )}

        {/* Artist About & Creative Philosophy */}
        <AboutSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Fullscreen Inspector Modal */}
      <ProjectInspectorModal
        project={inspectedProject}
        onClose={() => setInspectedProject(null)}
        onNavigate={handleNavigateProject}
        onEditProject={handleOpenEdit}
        onDeleteProject={handleDeleteProject}
        onSetFeatured={handleSetFeaturedProject}
      />

      {/* Project Editor Modal (Add & Edit with flexible stats & multi-shader views) */}
      <ProjectEditorModal
        isOpen={isEditorOpen}
        onClose={() => {
          setIsEditorOpen(false);
          setEditingProject(null);
        }}
        onSaveProject={handleSaveProject}
        editingProject={editingProject}
        totalProjects={projects.length}
      />

      {/* Reorder Modal */}
      <ReorderModal
        isOpen={isReorderOpen}
        onClose={() => setIsReorderOpen(false)}
        projects={projects}
        onSaveOrder={handleSaveReordered}
      />
    </div>
  );
}
